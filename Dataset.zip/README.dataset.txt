# Sementacion_Heridas > 2022-07-14 9:57pm
https://universe.roboflow.com/object-detection/sementacion_heridas

Provided by Roboflow
License: CC BY 4.0

